<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise 4</title>
    <link rel="stylesheet" type="text/css" href="exercise4.css">
    </head>
<body>
    <!-- EXERCISE 4 -->
    
    <!-- GET METHOD -->
    <form action="naragmarielleandrea_ex4.php" method="get">
        <label for="fname">Enter your Firstname:</label>
        <input type="text" id="fname" name="fname"><br><br>

        <label for="lname">Enter your Lastname:</label>
        <input type="text" id="lname" name="lname"><br><br>
        <input type="submit" value="Submit(get method)">
    </form>
</body>
</html>